from flask_app import app, bcrypt
from flask import render_template, redirect, request, session, flash
from flask_app.models.user_model import User

# --------------------------Display Routes-----------------------------#
@app.route('/')
def mainRoute():
    return render_template("mainRoute.html")


# --------------------------Action Routes-----------------------------#
@app.route('/register', methods=['POST'])
def register():
    if not User.validate_register(request.form):
        return redirect('/')
    
    user_data = {
        **request.form,
        'password' : bcrypt.generate_password_hash(request.form['password'])
    }
    session['id'] = User.create(user_data)
    return redirect('/sightings')


@app.route('/login', methods=['POST'])
def login():
    if not User.validate_login(request.form):
        return redirect('/')
    user = User.retrieve_one(email=request.form['login_email'])
    session['id'] = user.id
    return redirect('/sightings')


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')