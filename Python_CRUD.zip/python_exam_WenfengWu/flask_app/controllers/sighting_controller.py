from flask import render_template,redirect,request,session, flash
from flask_app import app
from flask_app.models.user_model import User
from flask_app.models.sighting_model import Sighting




#------------------------------Display-------------------#
@app.route('/sightings')
def sightings():
    if 'id' not in session:
        return redirect('/')
    context = {
        'logged_user' : User.retrieve_one(id = session['id']),
        'sightings' : Sighting.retrieve_all()
    }
    return render_template("sightings.html", **context)

@app.route('/sightings/new')
def new_sighting():
    context = {
        'logged_user' : User.retrieve_one(id = session['id'])
    }
    return render_template("new_sighting.html", **context)

@app.route('/sightings/view/<int:id>')
def view_sighting(id):
    context = {
        'logged_user' : User.retrieve_one(id = session['id']),
        'sighting' : Sighting.retrieve_one(id = id)
    }
    return render_template('view_sighting.html', **context)

@app.route('/sightings/edit/<int:id>')
def edit_sighting(id):
    context = {
        'logged_user' : User.retrieve_one(id = session['id']),
        'sighting' : Sighting.retrieve_one(id = id)
    }
    return render_template('edit_sighting.html', **context)


#------------------------------Actions-------------------#
@app.route('/sightings/create', methods=['POST'])
def create_sighting():
    if not Sighting.validate(request.form):
        return redirect('/sightings/new') 

    Sighting.create(**request.form, user_id = session['id'])

    return redirect('/sightings')


@app.route('/sightings/update/<int:id>', methods=['POST'])
def update_sighting(id):
    if not Sighting.validate(request.form):
        return redirect(f'/sightings/edit/{id}') 
    Sighting.update(**request.form, id = id)
    return redirect(f'/sightings/view/{id}')


@app.route('/sightings/delete/<int:id>')
def delete_sighting(id):
    Sighting.delete(id = id)
    return redirect('/sightings')

