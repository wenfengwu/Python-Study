from flask_app.controllers import user_controller
from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import DB, bcrypt
from flask import flash
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 

class User:
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']


#----------------------Property--------------------------#

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

#---------------------------Create----------------------#
    @classmethod
    def create(cls, data):
        query = '''
                INSERT INTO users 
                (first_name, last_name, email, password) 
                VALUES 
                (%(first_name)s,%(last_name)s,%(email)s,%(password)s);
                '''
        return connectToMySQL(DB).query_db(query, data)

#---------------------------Retrieve----------------------#
    @classmethod
    def retrieve_one(cls, **data):
        query = 'SELECT * FROM users WHERE '
        # list comprehension 
        wheres = [f"{key}=%({key})s" for key in data]
        # wheres = []
        # for key in data:
        #     wheres.append(f"{key}=%({key})s")
        where_str = ' AND '.join(wheres)
        # one line way -> generation expression
        # where_str = ' AND '.join([f"{key}=%({key})s" for key in data])
        query += where_str + ';'

        result = connectToMySQL(DB).query_db(query, data)
        if result:
            return cls(result[0])

    


#---------------------------Validation----------------------#
    @staticmethod
    def validate_register(data):
        errors = {}
        if len(data['first_name']) < 2:
            errors['first_name'] = 'First name should be at least 2 characters'
        if len(data['last_name']) < 2:
            errors['last_name'] = 'Last name should be at least 2 characters'
        if not EMAIL_REGEX.match(data['email']):
            errors['email'] = 'Email format is invalid'
        elif User.retrieve_one(email=data['email']):
            errors['email'] = 'Email is already in use'
        if len(data['password']) < 8:
            errors['password'] = 'Password should be at least 8 characters'
        elif data['password'] != data['confirm_password']:
            errors['confirm_password'] = 'Password do not match'

        for catefory, msg in errors.items():
            flash(msg, catefory)

        return len(errors) == 0


    @staticmethod
    def validate_login(data):
        errors = {}
        user = User.retrieve_one(email=data['login_email'])
        if not user:
            errors['login'] = 'Invalid Credentials'
        elif not bcrypt.check_password_hash(user.password, data['login_password']):
            errors['login'] = 'Invalid Credentials'

        for catefory, msg in errors.items():
            flash(msg, catefory)

        return len(errors) == 0