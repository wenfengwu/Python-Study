from flask_app.controllers import user_controller, sighting_controller
from flask_app.models import user_model
from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import DB
from flask import flash


class Sighting:
    def __init__(self, data):
        self.id = data['id']
        self.location = data['location']
        self.description = data['description']
        self.date_siting = data['date_siting']
        self.sasquatch = data['sasquatch']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user_id = data['user_id']

    #----------------------Create--------------------------#
    @classmethod
    def create(cls, **data):
        query = "INSERT INTO sightings (location, description, date_siting, sasquatch, user_id) VALUES (%(location)s, %(description)s, %(date_siting)s, %(sasquatch)s,%(user_id)s);"
        return connectToMySQL(DB).query_db(query,data)

    #----------------------Retrieve--------------------------#
    @classmethod 
    def retrieve_all(cls):
        query = '''
                SELECT * FROM sightings
                JOIN users
                ON sightings.user_id = users.id;
                '''
        results = connectToMySQL(DB).query_db(query)
        all_sightings = []
        for row in results:
            sighting = cls(row)
            creator_data = {
                **row,
                'id' : row['users.id'],
                'created_at' : row['users.created_at'],
                'updated_at' : row['users.updated_at']
            }
            sighting.created_by = user_model.User(creator_data)
            all_sightings.append(sighting)

        return all_sightings


    @classmethod
    def retrieve_one(cls, **data):
        query = "SELECT * FROM sightings JOIN users ON user_id = users.id WHERE sightings.id = %(id)s;"
        results = connectToMySQL(DB).query_db(query,data)
        if results:
            row = results[0]
            sighting = cls(row)
            creator_data = {
                **row,
                'id' : row['users.id'],
                'created_at' : row['users.created_at'],
                'updated_at' : row['users.updated_at']
            }
            sighting.created_by = user_model.User(creator_data)
            return sighting

    #----------------------Update--------------------------#

    @classmethod
    def update(cls, id, **data):
        query = "UPDATE sightings SET "
        #list comprehension
        #sub = []
        #for key in data:
        #   sub.append(f"{key}=%({key})s")
        #sub = [f"{key}=%({key})s" key in data]
        #join each sub element with ","
        set_str = ','.join(f"{key} = %({key})s" for key in data)
        
        query += set_str + " Where id = %(id)s;"
        return connectToMySQL(DB).query_db(query, {**data, 'id':id})



    #----------------------Delete--------------------------#
    @classmethod
    def delete(cls, **data):
        query = "DELETE FROM sightings WHERE id = %(id)s;"
        return connectToMySQL(DB).query_db(query,data)


    #----------------------Validation--------------------------#
    @staticmethod
    def validate(data):
        errors = {}
        if len(data['location']) < 1:
            errors['location'] = "Location must be filled out"
        if len(data['description']) < 3:
            errors['description'] = "Description must at least 3 characters"
        if len(data['date_siting']) < 1:
            errors['date_siting'] = "Date of siting is required"        
        if not data['sasquatch']:
            errors['sasquatch'] = "sasquatch must at least one"
        elif int(data['sasquatch']) < 1:
                errors['sasquatch'] = "sasquatch must at least one"

        for category, msg in errors.items():
            flash(msg, category)
        return len(errors) == 0

